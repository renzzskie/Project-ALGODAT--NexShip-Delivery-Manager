public class NodeStack {
    Paket data;
    NodeStack next;

    public NodeStack(Paket data) {
        this.data = data;
        this.next = null;
    }
}