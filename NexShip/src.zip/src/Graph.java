public class Graph {
    GraphNode firstNode;

    public void addNode(String name) {
        if (findNode(name) != null) return;
        GraphNode newNode = new GraphNode(name);
        newNode.next = firstNode;
        firstNode = newNode;
    }

    public GraphNode findNode(String name) {
        GraphNode current = firstNode;
        while (current != null) {
            if (current.name.equalsIgnoreCase(name)) return current;
            current = current.next;
        }
        return null;
    }

    public void addEdge(String srcName, String destName, int weight) {
        GraphNode src = findNode(srcName);
        GraphNode dest = findNode(destName);
        if (src != null && dest != null) {
            src.addEdge(dest, weight);
            dest.addEdge(src, weight); // Undirected
        }
    }

    // Search Node
    public GraphNode findNodeRecursive(String name) {
        GraphNode current = firstNode;
        while (current != null) {
            if (current.name.equalsIgnoreCase(name)) return current;
            if (current.nestedGraph != null) {
                GraphNode found = current.nestedGraph.findNodeRecursive(name);
                if (found != null) return found;
            }
            current = current.next;
        }
        return null;
    }

    // Reset status untuk Dijkstra ulang
    public void resetGraph() {
        GraphNode current = firstNode;
        while (current != null) {
            current.distance = Integer.MAX_VALUE;
            current.visited = false;
            current.previous = null;
            if (current.nestedGraph != null) {
                current.nestedGraph.resetGraph();
            }
            current = current.next;
        }
    }
}