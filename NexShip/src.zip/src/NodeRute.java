public class NodeRute {
    String namaTitik;
    NodeRute next;

    public NodeRute(String namaTitik) {
        this.namaTitik = namaTitik;
        this.next = null;
    }
}