public class ListNode {
    Object data;
    ListNode next;

    public ListNode(Object data) {
        this.data = data;
        this.next = null;
    }
}