public class Queue {
    MyLinkedList list = new MyLinkedList();

    public void enqueue(Object data) {
        list.addLast(data);
    }

    public Object dequeue() {
        return list.removeFirst();
    }

    public MyLinkedList getList() {
        return list;
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }
}