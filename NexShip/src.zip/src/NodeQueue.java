public class NodeQueue {
    Paket data;
    NodeQueue next;

    public NodeQueue(Paket data) {
        this.data = data;
        this.next = null;
    }
}